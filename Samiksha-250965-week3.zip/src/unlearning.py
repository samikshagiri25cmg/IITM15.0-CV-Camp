import torch

RESTRICTED_ARTISTS = [
    "Wassily Kandinsky",
    "Gustav Klimt",
    "Edvard Munch",
    "Frida Kahlo",
    "Amedeo Modigliani",
]

PRESERVE_STYLES = [
    "a painting in the style of Claude Monet",
    "a painting in the style of Vincent van Gogh",
    "a painting in the style of Pablo Picasso",
    "a painting in the style of Rembrandt",
    "a painting in the style of Leonardo da Vinci",
    "a painting of a cat, impressionist style",
    "a watercolor of a mountain lake",
    "a charcoal sketch of an old bridge",
    "a pop-art poster of a city skyline",
    "an ink illustration of a dragon",
    "a photo of a person",
    "oil on canvas portrait",
    "landscape photography",
]

TARGET_PROMPT = "a painting in the style of fine art"


def _last_token_emb(tokenizer, text_encoder, prompt: str, device, dtype):
    inp = tokenizer([prompt], padding="max_length", max_length=tokenizer.model_max_length,
                    return_tensors="pt").to(device)
    hidden = text_encoder(inp.input_ids)[0].to(device=device, dtype=dtype)
    eos_idx = (inp.input_ids[0] == tokenizer.eos_token_id).nonzero(as_tuple=True)[0][0].item()
    return hidden[0, eos_idx]


def apply_style_erasure(pipe, strength: float = 1.0, reg_lambda: float = 0.1):
    tokenizer = pipe.tokenizer
    text_encoder = pipe.text_encoder
    unet = pipe.unet
    device = text_encoder.device
    dtype = text_encoder.dtype

    # 1. Neutralize token embeddings in text encoder
    embedding_weight = text_encoder.get_input_embeddings().weight.data
    anchor_ids = tokenizer.encode("painting art artwork canvas", add_special_tokens=False)
    anchor_emb = embedding_weight[anchor_ids].mean(dim=0)
    anchor_dir = anchor_emb / anchor_emb.norm()

    artist_token_ids = set()
    for artist in RESTRICTED_ARTISTS:
        artist_token_ids.update(tokenizer.encode(artist, add_special_tokens=False))

    for tid in artist_token_ids:
        orig_norm = embedding_weight[tid].norm()
        embedding_weight[tid] = anchor_dir * orig_norm

    # 2. Closed-form UCE update on cross-attention to_v and to_k matrices
    with torch.no_grad():
        erase_prompts = [f"a painting in the style of {artist}" for artist in RESTRICTED_ARTISTS]
        c_erase = torch.stack([_last_token_emb(tokenizer, text_encoder, p, device, dtype)
                               for p in erase_prompts]).t()  # [768, N_e]

        c_target = _last_token_emb(tokenizer, text_encoder, TARGET_PROMPT, device, dtype).unsqueeze(1)  # [768, 1]
        c_target_expanded = c_target.expand(-1, c_erase.shape[1])  # [768, N_e]

        c_preserve = torch.stack([_last_token_emb(tokenizer, text_encoder, p, device, dtype)
                                 for p in PRESERVE_STYLES]).t()  # [768, N_p]

        d = c_erase.shape[0]
        # Invert (C_erase C_erase^T + C_preserve C_preserve^T + lambda I)
        A = (torch.matmul(c_erase, c_erase.t())
             + torch.matmul(c_preserve, c_preserve.t())
             + reg_lambda * torch.eye(d, device=device, dtype=dtype))
        A_inv = torch.inverse(A.to(torch.float32)).to(dtype)

        c_pres_sq = torch.matmul(c_preserve, c_preserve.t())

        target_modules = [m for m in unet.modules()
                          if m.__class__.__name__ == "Attention"
                          and hasattr(m, "to_v") and m.to_v.weight.shape[1] == d]

        for m in target_modules:
            for layer in (m.to_v, m.to_k):
                W = layer.weight.data
                V_e_star = torch.matmul(W, c_target_expanded)
                B = torch.matmul(V_e_star, c_erase.t()) + torch.matmul(W, c_pres_sq)
                W_new = torch.matmul(B, A_inv)
                W.copy_((1.0 - strength) * W + strength * W_new)

    print(f"Style erasure UCE: {len(erase_prompts)} erase, {len(PRESERVE_STYLES)} preserve concepts "
          f"(lambda={reg_lambda}, strength={strength})")
    return pipe
