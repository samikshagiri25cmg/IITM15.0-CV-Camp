import torch

TARGET_ROLES = [
    "CEO",
    "nurse",
    "construction worker",
    "secretary",
    "chef",
]

GENDER_PAIRS = [
    ("man", "woman"),
    ("male", "female"),
    ("gentleman", "lady"),
    ("boy", "girl"),
    ("he", "she"),
]

ROLE_KEYWORDS = ["ceo", "nurse", "construction", "secretary", "chef"]

PRESERVE_ROLES = [
    "a photo of a librarian",
    "a photo of a pilot",
    "a photo of a teacher",
    "a photo of a farmer",
    "a photo of a violinist",
    "a photo of a doctor",
    "a photo of an engineer",
    "a photo of a lawyer",
    "a photo of a scientist",
    "a photo of an artist",
    "a photo of a person",
    "a portrait of a person",
]


def _last_token_emb(tokenizer, text_encoder, prompt: str, device, dtype):
    inp = tokenizer([prompt], padding="max_length", max_length=tokenizer.model_max_length,
                    return_tensors="pt").to(device)
    hidden = text_encoder(inp.input_ids)[0].to(device=device, dtype=dtype)
    eos_idx = (inp.input_ids[0] == tokenizer.eos_token_id).nonzero(as_tuple=True)[0][0].item()
    return hidden[0, eos_idx]


def apply_debiasing(pipe, strength: float = 1.0, reg_lambda: float = 0.1):
    tokenizer = pipe.tokenizer
    text_encoder = pipe.text_encoder
    unet = pipe.unet
    device = text_encoder.device
    dtype = text_encoder.dtype

    # 1. Project out lexical gender direction from role token embeddings
    weight = text_encoder.get_input_embeddings().weight.data
    diffs = []
    for male_w, female_w in GENDER_PAIRS:
        m_ids = tokenizer.encode(male_w, add_special_tokens=False)
        f_ids = tokenizer.encode(female_w, add_special_tokens=False)
        if m_ids and f_ids:
            diff = weight[f_ids].mean(dim=0) - weight[m_ids].mean(dim=0)
            diffs.append(diff / diff.norm())

    if diffs:
        g = torch.stack(diffs).mean(dim=0)
        g = g / g.norm()
        for kw in ROLE_KEYWORDS:
            for tid in tokenizer.encode(kw, add_special_tokens=False):
                emb = weight[tid]
                weight[tid].copy_(emb - torch.dot(emb, g) * g)

    # 2. Closed-form UCE update on cross-attention to_v and to_k matrices
    with torch.no_grad():
        c_edit_list = []
        c_target_list = []
        for role in TARGET_ROLES:
            c_m = _last_token_emb(tokenizer, text_encoder, f"a photo of a male {role}", device, dtype)
            c_f = _last_token_emb(tokenizer, text_encoder, f"a photo of a female {role}", device, dtype)
            c_base = _last_token_emb(tokenizer, text_encoder, f"a photo of a {role}", device, dtype)
            c_edit_list.append(c_base)
            c_target_list.append(0.5 * (c_m + c_f))

        c_edit = torch.stack(c_edit_list).t()      # [768, N_edit]
        c_target = torch.stack(c_target_list).t()  # [768, N_edit]

        c_preserve = torch.stack([_last_token_emb(tokenizer, text_encoder, p, device, dtype)
                                 for p in PRESERVE_ROLES]).t()  # [768, N_p]

        d = c_edit.shape[0]
        # Invert (C_edit C_edit^T + C_preserve C_preserve^T + lambda I)
        A = (torch.matmul(c_edit, c_edit.t())
             + torch.matmul(c_preserve, c_preserve.t())
             + reg_lambda * torch.eye(d, device=device, dtype=dtype))
        A_inv = torch.inverse(A.to(torch.float32)).to(dtype)

        c_pres_sq = torch.matmul(c_preserve, c_preserve.t())

        target_modules = [m for m in unet.modules()
                          if m.__class__.__name__ == "Attention"
                          and hasattr(m, "to_v") and m.to_v.weight.shape[1] == d]

        for m in target_modules:
            for layer in (m.to_v, m.to_k):
                W = layer.weight.data
                V_e_star = torch.matmul(W, c_target)
                B = torch.matmul(V_e_star, c_edit.t()) + torch.matmul(W, c_pres_sq)
                W_new = torch.matmul(B, A_inv)
                W.copy_((1.0 - strength) * W + strength * W_new)

    print(f"Debiasing UCE: {len(TARGET_ROLES)} edit, {len(PRESERVE_ROLES)} preserve concepts "
          f"(lambda={reg_lambda}, strength={strength})")
    return pipe
