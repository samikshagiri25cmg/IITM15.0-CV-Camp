import os
import sys
import torch
from diffusers import StableDiffusionPipeline
from PIL import Image

src_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from unlearning import apply_style_erasure
from debiasing import apply_debiasing

MODEL_ID = "CompVis/stable-diffusion-v1-4"
REVISION = "133a221"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32


def load_model():
    pipe = StableDiffusionPipeline.from_pretrained(
        MODEL_ID,
        revision=REVISION,
        torch_dtype=DTYPE,
        # Safety checker must remain active to avoid evaluation disqualification
    ).to(DEVICE)
    pipe.set_progress_bar_config(disable=False)

    pipe = apply_style_erasure(pipe)
    pipe = apply_debiasing(pipe)
    return pipe


@torch.no_grad()
def generate(pipe, prompt: str, seed: int) -> Image.Image:
    generator = torch.Generator(device=DEVICE).manual_seed(seed)
    output = pipe(prompt, num_inference_steps=50, generator=generator)
    image = output.images[0]

    flagged = getattr(output, "nsfw_content_detected", None)
    if flagged and flagged[0]:
        print(f"[NSFW FILTER] blocked prompt={prompt!r} seed={seed}")
    return image
